# 1. Navigate to `cheats` folder
![Microsoft Edge part 1](/tutorial/edge/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Microsoft Edge part 2](/tutorial/edge/part%20(2).png)
# 3. Click `Download raw file`
![Microsoft Edge part 3](/tutorial/edge/part%20(3).png)
# 4. Ctrl + Shift + O or Right click bookmarks bar > Manage favorites
![Microsoft Edge part 4](/tutorial/edge/part%20(4).png)
# 5. Click 3 dots > Import favorites
![Microsoft Edge part 5](/tutorial/edge/part%20(5).png)
# 6. Import from IE11
![Microsoft Edge part 6](/tutorial/edge/part%20(6).png)
# 7. Switch to `Favorites or bookmarks HTML file`
![Microsoft Edge part 7](/tutorial/edge/part%20(7).png)
# 8. Click on `Choose File` and select saved file from step 3
![Microsoft Edge part 8](/tutorial/edge/part%20(8).png)
# 9. Go back to favorites page and create a new folder
![Microsoft Edge part 9](/tutorial/edge/part%20(9).png)
# 10. Open `Other favorites` folder and select all (Ctrl + A)
![Microsoft Edge part 10](/tutorial/edge/part%20(10).png)
# 11. Drag to folder created in step 9
![Microsoft Edge part 11](/tutorial/edge/part%20(11).png)
# 12. Happy cheating
![Microsoft Edge part 12](/tutorial/edge/part%20(12).png)