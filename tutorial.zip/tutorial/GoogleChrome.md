# 1. Navigate to `cheats` folder
![Google Chrome part 1](/tutorial/chrome/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Google Chrome part 2](/tutorial/chrome/part%20(2).png)
# 3. Click `Download raw file`
![Google Chrome part 3](/tutorial/chrome/part%20(3).png)
# 4. Right click bookmarks bar > Bookmark manager
![Google Chrome part 4](/tutorial/chrome/part%20(4).png)
# 5. Click 3 dots > Import bookmarks
![Google Chrome part 5](/tutorial/chrome/part%20(5).png)
# 6. Choose saved file from step 3
![Google Chrome part 6](/tutorial/chrome/part%20(6).png)
# 7. Happy cheating
![Google Chrome part 7](/tutorial/chrome/part%20(7).png)